package assignment2;

import java.util.ArrayList;
import java.util.Collections;

/**
 *
 * @author   Muhammad Ahsan Anjum Butt
 * @email    l134169@lhr.nu.edu.pk
 * @section  CS-B
 * @function    
 */
public class PalindromeWorker extends Thread
{
    private static Integer ID_Counter = 0;
    private Integer ID;
    private ArrayList<ArrayList<String>> tasks;
    private ArrayList<Object> sharedArr;
    
    public PalindromeWorker(ArrayList<ArrayList<String>> tasks, ArrayList<Object> sharedArr)
    {
        this.ID = ID_Counter++;
        this.tasks = tasks;
        this.sharedArr = sharedArr;
    }

    @Override
    public void run()
    {
        super.run();
        int palindromeCount = 0;
        StringBuffer temp = new StringBuffer();
        
        while(tasks.size() > 0)
        {
            ArrayList<String> task = tasks.get(0);
            while(task.size() > 0)
            {
                String word = task.get(0);
                temp.append(word);
                String reversedWord = temp.reverse().toString();
                temp.delete(0, temp.length());
                
                if(word.equals(reversedWord))
                {
                    synchronized(sharedArr)
                    {
//                        System.out.println("Thread " + ID + ", 1 added");
                        sharedArr.add(word);
                    }
                    ++palindromeCount;
                    task.remove(0);
                }
                else
                {
                    int indexOfReversedWord = Collections.binarySearch(task, reversedWord);
                    if(indexOfReversedWord >= 0)
                    {
                        synchronized(sharedArr)
                        {
                            sharedArr.add(word);
                            sharedArr.add(reversedWord);
//                            System.out.println("Thread " + ID + ", 2 added");
                        }
                        task.remove(indexOfReversedWord);
                        palindromeCount += 2;
                    }
                    task.remove(0);
                }
            }
            tasks.remove(0);
        }
        synchronized(sharedArr)
        {
            sharedArr.add((Integer)ID);
            sharedArr.add((Integer)palindromeCount);
        }
    }

}
