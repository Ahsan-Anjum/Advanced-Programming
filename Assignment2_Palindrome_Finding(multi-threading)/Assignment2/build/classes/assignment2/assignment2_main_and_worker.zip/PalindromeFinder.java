
package assignment2;

import java.io.*;
import java.util.*;
import org.omg.CORBA.Environment;

/**
 *
 * @author    Muhammad Ahsan Anjum Butt
 * @email     l134169@lhr.nu.edu.pk
 * @section   CS-B
 * @function      
 */
public class PalindromeFinder
{

    /**
     * @param args the command line arguments
     */
    public static final String folderPath = "/home/code-sage/NetBeansProjects/Assignment2/src/assignment2/";
    private static HashMap<Integer, ArrayList<String>> bagOfTasks;
    private static Integer w;
    
    private static void readWordsFromFile()
    {
        try
        {
            File dictFile = new File(folderPath + "words.txt");
            FileReader reader = new FileReader(dictFile);
            BufferedReader buffReader = new BufferedReader(reader);
            
            bagOfTasks = new HashMap<Integer, ArrayList<String>>();
            String temp;
            while ((temp = buffReader.readLine()) != null)
            {
                temp = temp.trim();
                ArrayList<String> sameLenWords = bagOfTasks.get(temp.length());
                if(sameLenWords != null)
                    sameLenWords.add(temp);
                else
                {                        
                    ArrayList<String> newLenWords = new ArrayList<String>();
                    newLenWords.add(temp);
                    bagOfTasks.put(temp.length(), newLenWords);
                }
            }
            
            buffReader.close();
            for(ArrayList<String> sameLenWords:bagOfTasks.values())
            {
                Collections.sort(sameLenWords);
            }
        }
        catch(IOException e)
        {
            
        }
    }
    
    private static ArrayList<ArrayList<ArrayList<String>>> makeTaskDistribution()
    {
        ArrayList<ArrayList<ArrayList<String>>> taskDistribution = new ArrayList<ArrayList<ArrayList<String>>>();
        for(int i = 0; i < w; i++)
            taskDistribution.add(new ArrayList<ArrayList<String>>());
        int i = 0;
        for(int key:bagOfTasks.keySet())
        {
            taskDistribution.get(i % w).add(bagOfTasks.get(key));
            i++;
        }
        return taskDistribution;
    }
    
    public static void main(String[] args) throws InterruptedException
    {
        w = Integer.parseInt(args[0]);
        
        readWordsFromFile();
        
        ArrayList<Object> sharedArr = new ArrayList<Object>();
        
        ArrayList<ArrayList<ArrayList<String>>> taskDistribution = makeTaskDistribution();
        
        PalindromeWriter writer = new PalindromeWriter(sharedArr, w);
        writer.start();
        
        PalindromeWorker[] workers = new PalindromeWorker[w];
        for(int j = 0; j < w; j++)
        {
            workers[j] = new PalindromeWorker(taskDistribution.get(j), sharedArr);
            workers[j].start();
        }
        
        writer.join();
        
    }

}
